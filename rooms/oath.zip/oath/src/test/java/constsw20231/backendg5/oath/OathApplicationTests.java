package constsw20231.backendg5.oath;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OathApplicationTests {

	@Test
	void contextLoads() {
	}

}

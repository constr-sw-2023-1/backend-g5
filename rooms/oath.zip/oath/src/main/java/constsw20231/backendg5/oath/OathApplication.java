package constsw20231.backendg5.oath;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OathApplication {

	public static void main(String[] args) {
		SpringApplication.run(OathApplication.class, args);
	}

}
